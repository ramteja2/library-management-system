# library-management-system
A Django-React based library management system with QR/barcode scanning and multi-role logins.
